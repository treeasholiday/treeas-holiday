Tree As Holiday - Static Website
--------------------------------
Files:
- index.html
- assets/logo.png

Cara deploy cepat:
1) Netlify: buat akun gratis di netlify.com -> drag & drop file ZIP atau folder.
2) GitHub Pages: buat repositori baru, upload semua file, lalu aktifkan GitHub Pages di Settings -> Pages -> Deploy from branch.
3) Vercel: buat akun, pilih 'Import Project' lalu upload folder.

Kontak:
WhatsApp: +62 813 95000 269
Email: treeasholiday@gmail.com
